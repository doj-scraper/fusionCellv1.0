import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import type { OrderStatus } from '@/lib/admin-api';

const statusConfig: Record<string, { label: string; className: string }> = {
  pending:    { label: 'Pending',    className: 'bg-orange-100 text-orange-800 border-orange-200' },
  paid:       { label: 'Paid',       className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  processing: { label: 'Processing', className: 'bg-blue-100 text-blue-800 border-blue-200' },
  shipped:    { label: 'Shipped',    className: 'bg-green-100 text-green-800 border-green-200' },
  cancelled:  { label: 'Cancelled',  className: 'bg-red-100 text-red-800 border-red-200' },
  refunded:   { label: 'Refunded',   className: 'bg-purple-100 text-purple-800 border-purple-200' },
};

export function StatusBadge({ status }: { status: string }) {
  const config = statusConfig[status] ?? { label: status, className: '' };
  return (
    <Badge variant="outline" className={cn('text-xs font-medium', config.className)}>
      {config.label}
    </Badge>
  );
}
