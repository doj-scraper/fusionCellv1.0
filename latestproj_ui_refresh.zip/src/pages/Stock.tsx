import { useCallback, useEffect, useState } from 'react';
import { adminProductsList } from '@/lib/admin-products-api';
import { adminInventoryAdjust, getAdminErrorMessage, type ProductPayload } from '@/lib/admin-api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { Search, ChevronLeft, ChevronRight, Plus, Minus, Package } from 'lucide-react';

interface Product extends ProductPayload {
  id: string;
  created_at: string;
  updated_at: string;
}

// Stock level indicator component
function StockIndicator({ quantity }: { quantity: number }) {
  let colorClass = 'bg-emerald-500';
  if (quantity < 5) {
    colorClass = 'bg-red-500';
  } else if (quantity < 10) {
    colorClass = 'bg-orange-500';
  }

  return (
    <div className="flex items-center gap-2">
      <span className={`inline-block h-2.5 w-2.5 rounded-full ${colorClass}`} />
      <span className={quantity < 5 ? 'text-red-600 font-semibold' : quantity < 10 ? 'text-orange-600 font-medium' : ''}>
        {quantity}
      </span>
    </div>
  );
}

// Quick Adjust Dialog
function AdjustDialog({
  open,
  onOpenChange,
  product,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product | null;
  onSuccess: () => void;
}) {
  const [delta, setDelta] = useState(0);
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      setDelta(0);
      setReason('');
    }
  }, [open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || delta === 0) return;

    setLoading(true);
    try {
      await adminInventoryAdjust({
        product_id: product.id,
        delta,
        reason: reason.trim() || undefined,
      });
      toast({
        title: 'Stock adjusted',
        description: `${product.sku}: ${delta > 0 ? '+' : ''}${delta} units`,
      });
      onOpenChange(false);
      onSuccess();
    } catch (err) {
      toast({
        title: 'Error adjusting stock',
        description: getAdminErrorMessage(err),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const newStock = product ? product.stock_quantity + delta : 0;
  const wouldGoNegative = newStock < 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Adjust Stock</DialogTitle>
          <DialogDescription>
            {product ? `${product.name} (${product.sku})` : ''}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Current stock display */}
          <div className="flex items-center justify-between rounded-md border border-border bg-muted/50 p-3">
            <span className="text-sm text-muted-foreground">Current Stock</span>
            <StockIndicator quantity={product?.stock_quantity ?? 0} />
          </div>

          {/* Delta input with +/- buttons */}
          <div className="space-y-2">
            <Label htmlFor="delta">Adjustment</Label>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setDelta((d) => d - 1)}
                disabled={loading}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Input
                id="delta"
                type="number"
                value={delta}
                onChange={(e) => setDelta(parseInt(e.target.value) || 0)}
                className="text-center font-mono text-lg"
                disabled={loading}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setDelta((d) => d + 1)}
                disabled={loading}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {/* Preview new stock */}
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">New stock will be:</span>
              <span className={wouldGoNegative ? 'text-red-600 font-semibold' : 'font-medium'}>
                {newStock}
              </span>
            </div>
            {wouldGoNegative && (
              <p className="text-xs text-red-600">Stock cannot go below zero.</p>
            )}
          </div>

          {/* Reason input */}
          <div className="space-y-2">
            <Label htmlFor="reason">Reason (optional)</Label>
            <Textarea
              id="reason"
              placeholder="e.g., Received shipment, Damaged goods, Inventory count..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={2}
              disabled={loading}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || delta === 0 || wouldGoNegative}>
              {loading ? 'Saving...' : 'Confirm'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Stock() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [adjustProduct, setAdjustProduct] = useState<Product | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const result = await adminProductsList({
        search,
        page,
        per_page: 50,
        sort_by: 'stock_quantity',
        sort_asc: true,
      });
      setProducts(result.products as Product[]);
      setTotalPages(result.total_pages);
      setTotal(result.total);
    } catch (err) {
      toast({ title: 'Error', description: getAdminErrorMessage(err), variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [search, page, toast]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Debounced search
  const [searchInput, setSearchInput] = useState('');
  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(searchInput);
      setPage(1);
    }, 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  const openAdjustDialog = (product: Product) => {
    setAdjustProduct(product);
    setDialogOpen(true);
  };

  // Count low stock items
  const criticalCount = products.filter((p) => p.stock_quantity < 5).length;
  const warningCount = products.filter((p) => p.stock_quantity >= 5 && p.stock_quantity < 10).length;

  return (
    <div className="space-y-6">
      <div className="rounded-[28px] border border-white/10 bg-gradient-to-br from-white/[0.05] to-white/[0.02] p-5 shadow-[0_24px_70px_rgba(0,0,0,0.16)]">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Inventory</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Sorted by lowest stock first
          </p>
        </div>
        {/* Stock level summary badges */}
        <div className="mt-4 flex flex-wrap items-center gap-3">
          {criticalCount > 0 && (
            <div className="flex items-center gap-1.5 rounded-full bg-red-100 px-3 py-1 text-sm font-medium text-red-700 dark:bg-red-900/30 dark:text-red-400">
              <span className="h-2 w-2 rounded-full bg-red-500" />
              {criticalCount} critical
            </div>
          )}
          {warningCount > 0 && (
            <div className="flex items-center gap-1.5 rounded-full bg-orange-100 px-3 py-1 text-sm font-medium text-orange-700 dark:bg-orange-900/30 dark:text-orange-400">
              <span className="h-2 w-2 rounded-full bg-orange-500" />
              {warningCount} low
            </div>
          )}
        </div>
      </div>

      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by SKU or name..."
          className="pl-9"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
        />
      </div>

      {/* Loading state */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      ) : products.length === 0 ? (
        /* Empty state */
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Package className="mb-4 h-12 w-12 text-muted-foreground/50" />
          <p className="text-muted-foreground">No products found.</p>
          {search && (
            <Button variant="link" className="mt-2" onClick={() => setSearchInput('')}>
              Clear search
            </Button>
          )}
        </div>
      ) : isMobile ? (
        /* Mobile: card layout */
        <div className="space-y-3">
          {products.map((p) => (
            <Card key={p.id} className={p.stock_quantity < 5 ? 'border-red-300 dark:border-red-800' : p.stock_quantity < 10 ? 'border-orange-300 dark:border-orange-800' : ''}>
              <CardContent className="flex items-center justify-between p-4">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.sku}</p>
                  <div className="mt-2">
                    <StockIndicator quantity={p.stock_quantity} />
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => openAdjustDialog(p)}>
                  Adjust
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        /* Desktop: table layout */
        <div className="rounded-md border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>SKU</TableHead>
                <TableHead>Name</TableHead>
                <TableHead className="text-right">Stock</TableHead>
                <TableHead className="text-center">Level</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((p) => (
                <TableRow
                  key={p.id}
                  className={
                    p.stock_quantity < 5
                      ? 'bg-red-50 dark:bg-red-950/30'
                      : p.stock_quantity < 10
                      ? 'bg-orange-50 dark:bg-orange-950/30'
                      : ''
                  }
                >
                  <TableCell className="font-mono text-xs">{p.sku}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{p.name}</TableCell>
                  <TableCell className="text-right">
                    <span
                      className={
                        p.stock_quantity < 5
                          ? 'text-red-600 font-semibold'
                          : p.stock_quantity < 10
                          ? 'text-orange-600 font-medium'
                          : ''
                      }
                    >
                      {p.stock_quantity}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span
                      className={`inline-block h-3 w-3 rounded-full ${
                        p.stock_quantity < 5
                          ? 'bg-red-500'
                          : p.stock_quantity < 10
                          ? 'bg-orange-500'
                          : 'bg-emerald-500'
                      }`}
                    />
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {new Date(p.updated_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => openAdjustDialog(p)}>
                      Adjust
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <p className="text-xs text-muted-foreground">
            {total} product{total !== 1 ? 's' : ''}
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" disabled={page <= 1} onClick={() => setPage(page - 1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">
              {page} / {totalPages}
            </span>
            <Button variant="outline" size="icon" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Adjust Dialog */}
      <AdjustDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        product={adjustProduct}
        onSuccess={fetchProducts}
      />
    </div>
  );
}
